
# Running the Code

To run the code, follow these steps:

1. Unzip the provided zip file.
2. Navigate to the directory using the command `cd cs1210095_cs1210581_cs1210552`.
3. Compile all executables using the command `make all`. Note that this will generate the executables in the same directory.
4. Once compiled, preprocessed images can be found in the folder `pre-proc-img/`, and the outputs will be written to the folder `output/`. In subtasks 3 and 4, the code is hardcoded to read 10,000 files in the `pre-proc-img/` folder, which takes approximately 20 seconds (including reading weights and matrices, inference, and output).

## Example Input and Output

Some example input and output commands are provided below:

```bash
./subtask1 1 3 2 2 1 0 0 0 1 0 0 0 1 1 0 0 1

./subtask1 1 3 2 0 1 0 0 0 1 0 0 0 1 1 0 0 1

./subtask1 2 1 3 3 -1 -1 1 -1 1 1 1 1 1 

./subtask1 3 1 2 4 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16

./subtask1 4 1 1 2 3 4 5 6 7 8
```

The same commands can be used for subtask 2 since the input format remains the same.

For subtasks 3 and 4, use the following commands:

```bash
./subtask3

./subtask4 0

./subtask4 1
```

--- 

This README provides instructions for compiling and running the code, as well as example commands for each subtask.
